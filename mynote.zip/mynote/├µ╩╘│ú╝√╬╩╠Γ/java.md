# java面试总结

## java基础知识

### comparator和comparable的比较

- Comparable 是“比较”的意思，而 Comparator 是“比较器”的意思；

- Comparable 是通过重写 compareTo 方法实现排序的，而 Comparator 是通过重写 compare 方法实现排序的；

- Comparable 必须由自定义类内部实现排序方法，而 Comparator 是外部定义并实现排序的。

### instanceof

在Java中，instanceof 是一个运算符，用于测试一个对象是否是特定类的一个实例或者是其子类的实例。

### equals方法的实现

- 调用父类的equals方法，如果为true，继续执行

- 判断是否和this相等

- 判断是否和null相等

- 调用getclass类方法，判断两者是否相等

- 强制类型转换，然后比较字段是否相等。

### 对象的构造

- 按照类定义的顺序执行静态初始化语句和初始化块

- 按照类定义的顺序执行域的初始化语句和初始化块

- 执行构造器

### 接口和抽象类的区别

- 抽象类是对类整体进行抽象，包括属性和行为；接口只是对行为进行的一种抽象

- 抽象类中可以含有静态代码和静态代码块；接口不能

- 一个类只能继承一个抽象类，但是可以实现多个接口

### java中的异常

- Error：Error类层次结构描述了Java运行时系统的内部错误和资源耗尽错误。非受查异常

- RuntimeException：程序错误导致的异常属于RuntimeException。非受查异常

- IOException: 

### 反射




